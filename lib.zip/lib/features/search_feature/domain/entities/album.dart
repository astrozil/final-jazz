
import 'package:jazz/features/search_feature/domain/entities/thumbnails.dart';
import 'package:jazz/features/stream_feature/domain/entities/RelatedSong.dart';

class Album {
  final String artist;
  final String artistId;
  final String description;
  final String duration;
  final YtThumbnail ytThumbnail;
  final String title;
  final int trackCount;
  final List<RelatedSong> tracks;
  final String year;
  final String type;

  Album({required this.artist, required this.artistId, required this.description, required this.duration, required this.ytThumbnail, required this.title, required this.trackCount, required this.tracks,required this.year,required this.type});
}