import 'package:dio/dio.dart';
import 'package:jazz/features/search_feature/domain/entities/thumbnails.dart';

import '../../domain/entities/song.dart';

class YouTubeDataSource {
  final Dio dio = Dio();
  // static const String apiKey = "AIzaSyCXWTzkdknx6qJAduHqCq-N_YbRFzyGizY"; //'AIzaSyArjPFna3-vQs5mgeeGecIXpNk0uEh0mto'; //"AIzaSyAFN4SphYax-xanBS7SPnrBEtsxuHbs01A";
  // static const String baseUrl = 'https://www.googleapis.com/youtube/v3/search';
    static const String baseUrl = 'https://ytmusic-4diq.onrender.com/search';

  Future<List<Song>?> searchSongs(String query) async {


      // final response = await dio.get(baseUrl, queryParameters: {
      //   'part': 'snippet',
      //   'q': query,
      //   'type': 'video',
      //   'maxResults': 10,
      //
      //   'topicId': '/m/04rlf',
      //   'key': apiKey,
      // });
       final response = await dio.get(baseUrl,queryParameters: {
         "query": query
       });
      // If download link fetched successfully
      if (response.statusCode == 200 && response.data != null) {
        var data = response.data;
        List<Song> songs = [];
        for(var video in data){
          songs.add(
              Song(
                url: "https://www.youtube.com/watch?v=${video['videoId']}", // Construct URing videoId
                title: video['title'] ?? "", // Get title from snippet
                artist: video['artists'] != null ? video['artists'][0]['name'] : video['artist'] ?? ''  , // Get channel title from snippet
                id: video['videoId'] ?? "", // Get videoId
                kind: video['category'] ?? "",
                browseId: video['browseId'] ?? '',// Get the type of result (e.g., "youtube#video")
                thumbnails: YtThumbnails(
                  defaultThumbnail: YtThumbnail(
                    url: video['thumbnails'][0]['url'] ?? "",
                    width:video['thumbnails'][0]['width'] ?? 0,
                    height: video['thumbnails'][0]['height'] ?? 0,
                  ),
                  mediumThumbnail: YtThumbnail(
                    url: video['thumbnails'][0]['url'] ?? "",
                    width:video['thumbnails'][0]['width'] ?? 0,
                    height: video['thumbnails'][0]['height'] ?? 0,
                  ),
                  highThumbnail: YtThumbnail(
                    url: video['thumbnails'][0]['url'] ?? "",
                    width:video['thumbnails'][0]['width'] ?? 0,
                    height: video['thumbnails'][0]['height'] ?? 0,
                  ),
                ),
              )
          );
        }

      return  songs;

      } else {

        throw Exception("Failed to fetch download link: ${response.statusCode}");
      }


    return null;
  }


}
