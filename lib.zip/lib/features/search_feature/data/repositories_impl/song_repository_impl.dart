import 'package:dartz/dartz.dart';
import 'package:jazz/core/failure/failure.dart';
import 'package:jazz/features/search_feature/data/data_sources/album_data_source.dart';
import 'package:jazz/features/search_feature/data/data_sources/youtube_data_source.dart';
import 'package:jazz/features/search_feature/domain/entities/album.dart';
import 'package:jazz/features/search_feature/domain/entities/song.dart';
import 'package:jazz/features/search_feature/domain/entities/thumbnails.dart';


import '../../domain/repositories/song_repository.dart';


class SongRepositoryImpl implements SongRepository {
  final YouTubeDataSource dataSource;
  final AlbumDatasource albumDatasource;
  SongRepositoryImpl({required this.dataSource,required this.albumDatasource});

  @override
  Future<List<Song>?> searchSongs(String query) async {
    List<Song>? songs =  await dataSource.searchSongs(query);

    if(songs != null){
      return songs;
    }
    return null;
  }

  @override
  Future<Either<Failure, Album>> searchAlbum(String albumId) {
    return  albumDatasource.searchAlbumMetadata(albumId);
  }

  @override
  Future<Either<Failure, YtThumbnail>> fetchTrackThumbnail(String songId) {

   return albumDatasource.fetchTrackThumbnail(songId);
  }
}
