part of 'shuffle_bloc.dart';

@immutable
sealed class ShuffleEvent {}

class ShuffleSongsEvent extends ShuffleEvent{

}

class UnShuffleSongsEvent extends ShuffleEvent{

}