part of 'shuffle_bloc.dart';

@immutable
sealed class ShuffleState {}

final class ShuffleInitial extends ShuffleState {}

final class ShuffledSongsState extends ShuffleState{

}


final class UnShuffledSongsState extends ShuffleState{

}