import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'shuffle_event.dart';
part 'shuffle_state.dart';

class ShuffleStateBloc extends Bloc<ShuffleEvent, ShuffleState> {
  ShuffleStateBloc() : super(UnShuffledSongsState()) {
    on<ShuffleSongsEvent>((event, emit) {
      emit(ShuffledSongsState());
    });

    on<UnShuffleSongsEvent>((event,emit){
      emit(UnShuffledSongsState());
    });
  }
}
