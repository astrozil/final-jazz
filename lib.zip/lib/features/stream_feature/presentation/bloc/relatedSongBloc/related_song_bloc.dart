import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:jazz/features/stream_feature/domain/entities/RelatedSong.dart';
import 'package:jazz/features/stream_feature/domain/usecases/getRelatedSongUsecase.dart';
import 'package:jazz/features/stream_feature/presentation/bloc/mp3StreamBloc/mp3_stream_bloc.dart';

part 'related_song_event.dart';
part 'related_song_state.dart';

class RelatedSongBloc extends Bloc<RelatedSongEvent, RelatedSongState> {
  final GetRelatedSongUseCase getRelatedSongUseCase;
  RelatedSongBloc(this.getRelatedSongUseCase) : super(const FetchRelatedSongInitial()){

  on<FetchRelatedSongEvent> (( event,emit)async {
print("OOOOOOOOOOOOOOOOOOOOO");

    try {
      final relatedSongs = await getRelatedSongUseCase(event.videoId,event.relatedSongsList);
      relatedSongs.fold(
              (failure) {
            emit(FetchRelatedSongError(failure.message));
          },
              (relatedSongList) {
            if (relatedSongList != null) {

              print("HOOOOOOOOOOOOOOOOOOOOOEEEEE");
              emit(FetchRelatedSongFinished(relatedSongList));
              print("NNNNNNNNNNNNNN");
            }
          }
      );
    } catch (_) {
      emit(const FetchRelatedSongError("Fetching Related Song failed"));
    }});

  }
  }

