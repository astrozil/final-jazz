part of 'related_song_bloc.dart';

sealed class RelatedSongState extends Equatable {

  const RelatedSongState();

}


final class FetchRelatedSongInitial extends RelatedSongState{

  const FetchRelatedSongInitial();

  @override
  // TODO: implement props
  List<Object?> get props => [];


}


final class FetchRelatedSongFinished extends RelatedSongState{
  final List<RelatedSong> relatedSong;
  const FetchRelatedSongFinished(this.relatedSong);
  @override
  // TODO: implement props
  List<Object?> get props => [relatedSong];

}
final class FetchRelatedSongError extends RelatedSongState{
  final String message;
  const FetchRelatedSongError(this.message);
  @override
  // TODO: implement props
  List<Object?> get props => [message];

}

