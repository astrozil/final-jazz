part of 'related_song_bloc.dart';

sealed class RelatedSongEvent extends Equatable {
  const RelatedSongEvent();
}
final class FetchRelatedSongEvent extends RelatedSongEvent{

  final String videoId;
  final List<RelatedSong> relatedSongsList;
   const FetchRelatedSongEvent(this.videoId,this.relatedSongsList);
  @override
  // TODO: implement props
  List<Object?> get props => [];

}

