part of 'repeat_song_or_playlist_bloc.dart';

@immutable
sealed class RepeatSongOrPlaylistState {}

final class RepeatSongOrPlaylistInitial extends RepeatSongOrPlaylistState {}

final class NoRepeatState extends RepeatSongOrPlaylistState{

}
final class SongRepeatState extends RepeatSongOrPlaylistState{

}

final class PlaylistRepeatState extends RepeatSongOrPlaylistState{

}