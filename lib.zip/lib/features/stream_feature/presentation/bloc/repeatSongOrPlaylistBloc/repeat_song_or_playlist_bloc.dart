import 'package:bloc/bloc.dart';
import 'package:jazz/features/search_feature/domain/entities/song.dart';
import 'package:jazz/features/stream_feature/domain/entities/RelatedSong.dart';
import 'package:meta/meta.dart';

part 'repeat_song_or_playlist_event.dart';
part 'repeat_song_or_playlist_state.dart';

class RepeatSongOrPlaylistBloc extends Bloc<RepeatSongOrPlaylistEvent, RepeatSongOrPlaylistState> {
  RepeatSongOrPlaylistBloc() : super(NoRepeatState()) {
    on<RepeatSongEvent>((event, emit) {
     emit(SongRepeatState());
    });
    on<RepeatPlaylistEvent>((event, emit) {
      emit(PlaylistRepeatState());
    });
    on<UndoRepeatEvent>((event, emit) {
      emit(NoRepeatState());
    });
  }
}
