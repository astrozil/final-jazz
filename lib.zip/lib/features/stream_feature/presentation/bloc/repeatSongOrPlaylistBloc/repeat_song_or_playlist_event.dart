part of 'repeat_song_or_playlist_bloc.dart';

@immutable
sealed class RepeatSongOrPlaylistEvent {}

final class RepeatSongEvent extends RepeatSongOrPlaylistEvent{

}

final class RepeatPlaylistEvent extends RepeatSongOrPlaylistEvent{

}

final class UndoRepeatEvent extends RepeatSongOrPlaylistEvent{

}