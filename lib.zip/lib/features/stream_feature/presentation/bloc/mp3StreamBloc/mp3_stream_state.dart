part of 'mp3_stream_bloc.dart';

sealed class Mp3StreamState  {
  final Either<Song,DownloadedSong>? song;
  final Either<List<RelatedSong>,List<DownloadedSong>> relatedSongsList;
  final int currentSongIndex;

  const Mp3StreamState(this.song,this.relatedSongsList,this.currentSongIndex);

}

class Mp3StreamInitial extends Mp3StreamState {

  const Mp3StreamInitial(super.song,super.relatedSongsList,super.currentSongIndex);
}


class Mp3StreamLoading extends Mp3StreamState {

   const Mp3StreamLoading(super.song,super.relatedSongsList,super.currentSongIndex,);
}




class Mp3StreamPaused extends Mp3StreamState {

  const Mp3StreamPaused(super.song,super.relatedSongsList,super.currentSongIndex,);
}


class Mp3StreamError extends Mp3StreamState {
  final String message;

  const Mp3StreamError(this.message,super.song,super.relatedSongsList,super.currentSongIndex);


}



class RelatedSongFetchedState extends Mp3StreamState {
  final Duration songPosition;
  const RelatedSongFetchedState(this.songPosition,super.song, super.relatedSongsList, super.currentSongIndex);



}

class ShuffledSongHistoryState extends Mp3StreamState{
  const ShuffledSongHistoryState(super.song,super.relatedSongsList,super.currentSongIndex);
}

class UnShuffledSongHistoryState extends Mp3StreamState{
  const UnShuffledSongHistoryState(super.song,super.relatedSongsList,super.currentSongIndex);
}
class UpdateSongHistoryState extends Mp3StreamState{
  const UpdateSongHistoryState(super.song,super.relatedSongsList,super.currentSongIndex);
}