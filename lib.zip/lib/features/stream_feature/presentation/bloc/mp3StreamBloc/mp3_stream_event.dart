part of 'mp3_stream_bloc.dart';

sealed class Mp3StreamEvent extends Equatable {

  @override
  List<Object> get props => [];
}
final class PlayMp3Stream extends Mp3StreamEvent{
  final Either<Song,DownloadedSong> song;


  PlayMp3Stream(this.song,);

  @override
  List<Object> get props => [song];

}

final class UpdatePlayerState extends Mp3StreamEvent{
  final Either<Song,DownloadedSong> song;
  final Mp3StreamState state;



  UpdatePlayerState(this.song,this.state);

  @override
  List<Object> get props => [song,state,];

}
class PauseMp3Stream extends Mp3StreamEvent {
  final Either<Song,DownloadedSong> song;
   PauseMp3Stream(this.song);

  @override
  List<Object> get props => [song];
}

class ResumeMp3Stream extends Mp3StreamEvent {
  final Either<Song,DownloadedSong> song;
   ResumeMp3Stream(this.song);

  @override
  List<Object> get props => [song];
}
class PlayNextSong extends Mp3StreamEvent {

}
class Mp3StreamStopped extends Mp3StreamEvent {
  final Either<Song,DownloadedSong> song;
   Mp3StreamStopped(this.song);

  @override
  List<Object> get props => [song];
}

class PlayPreviousSong extends Mp3StreamEvent {
  final Either<Song,DownloadedSong> song;
  PlayPreviousSong(this.song);

  @override
  List<Object> get props => [song];
}

class FetchSongHistoryEvent extends Mp3StreamEvent{

  @override
  List<Object> get props => [];

}

class PlayChosenSongFromRelatedSongs extends Mp3StreamEvent{
  final int chosenIndex;
  PlayChosenSongFromRelatedSongs(this.chosenIndex);
  @override
  List<Object> get props => [chosenIndex];
}

class ShuffleSongHistoryEvent extends Mp3StreamEvent{
    final Either<Song,DownloadedSong> song;
    ShuffleSongHistoryEvent(this.song);
    @override
    List<Object> get props => [song];
}

class UnShuffleSongHistoryEvent extends Mp3StreamEvent{
   final Either<Song,DownloadedSong> song;
   UnShuffleSongHistoryEvent(this.song);
   @override
   List<Object> get props => [song];
}

class RepeatCurrentSongEvent extends Mp3StreamEvent{

  @override
  List<Object> get props => [];
}

class RepeatSongPlaylistEvent extends Mp3StreamEvent{
  @override
  List<Object> get props => [];
}


class UpdateSongHistoryEvent extends Mp3StreamEvent{
  final Either<List<RelatedSong>,List<DownloadedSong>> songList;
  final int index;

  UpdateSongHistoryEvent({required this.songList,required this.index});
  @override
  List<Object> get props => [songList,index];
  }
