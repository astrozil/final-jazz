import 'dart:async';
import 'dart:math';

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:jazz/features/download_feature/domain/entities/downloadedSong.dart';
import 'package:jazz/features/lyrics_feature/presentation/bloc/lyrics_bloc/lyrics_bloc.dart';

import 'package:jazz/features/search_feature/domain/entities/song.dart';

import 'package:jazz/features/stream_feature/domain/entities/RelatedSong.dart';
import 'package:jazz/features/stream_feature/domain/usecases/getMp3StreamUsecase.dart';
import 'package:jazz/features/stream_feature/domain/usecases/getRelatedSongUsecase.dart';
import 'package:jazz/features/stream_feature/presentation/bloc/relatedSongBloc/related_song_bloc.dart';
import 'package:jazz/features/stream_feature/presentation/bloc/repeatSongOrPlaylistBloc/repeat_song_or_playlist_bloc.dart';

import 'package:jazz/features/stream_feature/presentation/bloc/shuffleStateBloc/shuffle_bloc.dart';
import 'package:jazz/features/stream_feature/presentation/bloc/songPositionBloc/song_position_bloc.dart';

import 'package:just_audio/just_audio.dart';


part 'mp3_stream_event.dart';
part 'mp3_stream_state.dart';
class Mp3StreamBloc extends Bloc<Mp3StreamEvent, Mp3StreamState> {
  final RelatedSongBloc relatedSongBloc;

  final ShuffleStateBloc shuffleBloc;
  final SongPositionBloc songPositionBloc;
  final LyricsBloc lyricsBloc;
  final RepeatSongOrPlaylistBloc repeatSongOrPlaylistBloc;
  final GetMp3StreamUseCase getMp3StreamUseCase;
  final GetRelatedSongUseCase getRelatedSongUseCase;
  final AudioPlayer audioPlayer = AudioPlayer();
  StreamSubscription<Duration>? _positionSubscription;
  StreamSubscription<ProcessingState>? _processingStateSubscription;
  StreamSubscription? relatedSongSubscription;
  late StreamSubscription repeatSongOrPlaylistSubscription;
  late Either<List<RelatedSong>,List<DownloadedSong>> songHistory;
  late Either<List<RelatedSong>, List<DownloadedSong>> shuffledSongHistory;
  late Either<List<RelatedSong>, List<DownloadedSong>> unShuffledSongHistory;
  late Either<List<RelatedSong>, List<DownloadedSong>>  listUsedForShuffle;
  int currentSongIndex = 0;
  int songsToFetch = 5;



  Mp3StreamBloc(this.getMp3StreamUseCase,
      this.getRelatedSongUseCase,
      this.relatedSongBloc,
      this.shuffleBloc,
      this.songPositionBloc,
      this.repeatSongOrPlaylistBloc,
      this.lyricsBloc

      )
      : super(  Mp3StreamInitial(null, left([]), 0)) {
    on<PlayMp3Stream>(_playMp3Stream);
    on<UpdatePlayerState>(_updatePlayerState);
    on<PauseMp3Stream>(_pauseMp3Stream);
    on<ResumeMp3Stream>(_resumeMp3Stream);
    on<PlayNextSong>(_playNextSong);
    on<PlayPreviousSong>(_playPreviousSong);
    on<PlayChosenSongFromRelatedSongs>(_playChosenSongFromRelatedSongs);
    on<ShuffleSongHistoryEvent>(_shuffleSongHistoryEvent);
    on<UnShuffleSongHistoryEvent>(_unShuffleSongHistoryEvent);
    on<RepeatCurrentSongEvent>(_repeatCurrentSongEvent);
    on<RepeatSongPlaylistEvent>(_repeatSongPlaylistEvent);
    on<FetchSongHistoryEvent>(_fetchSongHistoryEvent);
    on<UpdateSongHistoryEvent>(_updateSongHistoryEvent);


  }

  Future<void> _playMp3Stream(
      PlayMp3Stream event, Emitter<Mp3StreamState> emit) async {

   await _resetVariables(event.song);

   if(shuffleBloc.state is ShuffledSongsState){
     shuffleBloc.add(
       UnShuffleSongsEvent()
     );
   }
   if(repeatSongOrPlaylistBloc.state is! NoRepeatState){
     repeatSongOrPlaylistBloc.add(UndoRepeatEvent());
   }
   songPositionBloc.add(
       NewSongChangedEvent()
   );


    _cancelSubscriptions();


    await event.song.fold((song)async{
       songHistory = left([]);
       emit(Mp3StreamLoading(event.song,songHistory,currentSongIndex+1));
       final mp3Stream = await getMp3StreamUseCase(song.id,song.url);


       await mp3Stream.fold(
             (failure) async => emit(Mp3StreamError("Stream Error", left(song),songHistory,currentSongIndex)),
             (mp3Stream) async {

           if (mp3Stream != null) {


             songHistory.leftMap((list){
                list.add(RelatedSong(
                  url: mp3Stream.url,
                  song: song,
                ));

              });


             try {

               add(FetchSongHistoryEvent());
                await playSong(left(song),mp3Stream.url,emit);


             } catch (e) {
               emit(Mp3StreamError('Failed to play MP3 stream',Left(song),songHistory,currentSongIndex));
             }
           } else {
             emit(Mp3StreamError('Failed to play MP3 stream', Left(song),songHistory,currentSongIndex));
           }
         },
       );
       },
             (downloadedSong)async{
              songHistory = right([]);

            await playSong(right(downloadedSong),"", emit);

             });





  }
  Future<void> playSong(Either<Song,DownloadedSong> song,String url,Emitter<Mp3StreamState> emit)async{


    await audioPlayer.stop();

     await song.fold(
          (song)async{

    add(UpdatePlayerState(left(song),Mp3StreamLoading(left(song), songHistory, currentSongIndex)));
    lyricsBloc.add(GetLyricsEvent(artist: song.artist, songName: song.title));


            if(url == ""){
              print("Downloading URL");
              try{
                final songUrlResponse = await getMp3StreamUseCase(song.id,song.url);
               await songUrlResponse.fold(
                        (failure)=> null,
                        (mp3Url)async {
                      if(mp3Url != null){
                        url = mp3Url.url;
                        songHistory.leftMap((list){
                          list[currentSongIndex] = list[currentSongIndex].copyWith(url: mp3Url.url);
                        });



                      }
                    }
                );
              }catch(e){
                await Future.delayed(const Duration(seconds: 5));
              }
            }
            await audioPlayer.setUrl(url);
          },
          (downloadedSong)async{
            add(UpdatePlayerState(right(downloadedSong),Mp3StreamLoading(right(downloadedSong), songHistory, currentSongIndex)));
            await audioPlayer.setFilePath(downloadedSong.songFile.path);
          }
      );



    _positionSubscription = audioPlayer.positionStream.listen((position) async {
      final totalDuration = audioPlayer.duration ?? Duration.zero;
      if (totalDuration >= position) {

        songPositionBloc.add(
            UpdateSongPositionEvent(
                position: position,
                totalDuration: totalDuration));


        Future<void> updateFetchedRelatedSongs() async {
         await songHistory.fold(
                  (relatedSongs) async {



                while (relatedSongs.length < songsToFetch) {
                  // add(FetchSongHistoryEvent());
                  await Future.delayed(const Duration(seconds: 1));

                }
              },
              (downloadedSongs)=> null


          );
        }

        await updateFetchedRelatedSongs();
      }
    });
    _processingStateSubscription = audioPlayer.processingStateStream.listen(
            (processingState) {
          if (processingState == ProcessingState.completed){
             final state = repeatSongOrPlaylistBloc.state;
            if( state is SongRepeatState){
          add(RepeatCurrentSongEvent());

            }else if(state is PlaylistRepeatState && currentSongIndex == songHistory.fold((relatedSongs)=>relatedSongs.length-1, (downloadedSongs)=> downloadedSongs.length-1)){
              add(RepeatSongPlaylistEvent());

            }
            else {
              add(PlayNextSong());
            }

          }
        });
    await audioPlayer.play();

  }



  Future<void> _updatePlayerState(
      UpdatePlayerState event, Emitter<Mp3StreamState> emit,) async {

    emit(event.state);

  }

  Future<void> _pauseMp3Stream(
      PauseMp3Stream event, Emitter<Mp3StreamState> emit) async {
    try {
      await audioPlayer.pause();
      emit(Mp3StreamPaused(event.song,songHistory,currentSongIndex));
    } catch (e) {
      emit(Mp3StreamError('Failed to pause MP3 stream', event.song,songHistory,currentSongIndex));
    }
  }

  Future<void> _resumeMp3Stream(
      ResumeMp3Stream event, Emitter<Mp3StreamState> emit) async {
    try {
      await audioPlayer.play();

    } catch (e) {
      emit(Mp3StreamError('Failed to resume MP3 stream', event.song,songHistory,currentSongIndex));
    }
  }
  void seekTo(Duration position) {
    audioPlayer.seek(position);
  }

  Future<void> _playNextSong(PlayNextSong event, Emitter<Mp3StreamState> emit) async {
    await audioPlayer.stop();
    songPositionBloc.add(
        NewSongChangedEvent()
    );
    _cancelSubscriptions();





     await songHistory.fold(
          (relatedSongs)async{
            if (currentSongIndex < getRelatedSongsLength() -1) {

              currentSongIndex++;
           await playSong(left(relatedSongs[currentSongIndex].song), relatedSongs[currentSongIndex].url,emit);
            if (currentSongIndex == relatedSongs.length - 1 && repeatSongOrPlaylistBloc.state is! PlaylistRepeatState) {

              songsToFetch += 20;
              add(FetchSongHistoryEvent());
            }}
          },
          (downloadedSongs)async{
      if (currentSongIndex < getDownloadedSongsLength() -1) {
        currentSongIndex++;


        await playSong(right(downloadedSongs[currentSongIndex]), "", emit);
      }  }
      );

    }






  Future<void> _playPreviousSong(
      PlayPreviousSong event, Emitter<Mp3StreamState> emit) async {
    _cancelSubscriptions();
    songPositionBloc.add(
         NewSongChangedEvent()
    );
    if (currentSongIndex > 0) {

      currentSongIndex--;
      songHistory.fold(
              (relatedSongs){
            playSong(left(relatedSongs[currentSongIndex].song), relatedSongs[currentSongIndex].url,emit);

          },
              (downloadedSongs){
            playSong(right(downloadedSongs[currentSongIndex]), downloadedSongs[currentSongIndex].artist,emit);
          }
      );


    } else {

      emit(Mp3StreamError("No previous song available", event.song,songHistory,currentSongIndex));
    }
  }

  Future<void> _playChosenSongFromRelatedSongs(PlayChosenSongFromRelatedSongs event,Emitter<Mp3StreamState> emit)async{
    _cancelSubscriptions();
    songPositionBloc.add(
        NewSongChangedEvent()
    );
    currentSongIndex = event.chosenIndex;
    songHistory.fold(
            (relatedSongs){
          playSong(left(relatedSongs[currentSongIndex].song), relatedSongs[currentSongIndex].url,emit);
          if(currentSongIndex == relatedSongs.length-1 && repeatSongOrPlaylistBloc.state is! PlaylistRepeatState){

            add(FetchSongHistoryEvent());
          }
        },
            (downloadedSongs){
          playSong(right(downloadedSongs[currentSongIndex]), downloadedSongs[currentSongIndex].artist,emit);
        }
    );




  }

  Future<void> _fetchSongHistoryEvent(FetchSongHistoryEvent event,Emitter<Mp3StreamState> emit) async {
   relatedSongSubscription?.cancel();
    songHistory.fold(
        (relatedSongs){
          relatedSongBloc.add(FetchRelatedSongEvent(relatedSongs.last.song.id, relatedSongs));
          relatedSongSubscription = relatedSongBloc.stream.listen((state){
            if(state is FetchRelatedSongFinished){



                  var updatedSongHistory = songHistory.leftMap((list){

                list.removeRange(0, list.length);
                   list.addAll(state.relatedSong);
                   return list;

                  });
                  songHistory = updatedSongHistory;
                  songsToFetch = getRelatedSongsLength();



            }
          });




        },
        (downloadedSongs){

        }
    );






  }

  bool _isDuplicateSong(String songTitle,List<RelatedSong> relatedSongs){
    final Set<String> keywordsToIgnore = {
      "lyrics","lyric video" ,"lyrics video", "playlist", "official", "video", "mood","edits","edit",
      "flaylist","by","lyric","music","tiktok","remix","speed up",
    };
    String normalizeTitle(String title) {
      title = title.toLowerCase();
      for (var keyword in keywordsToIgnore) {
        title = title.replaceAll(RegExp(r'\b' + keyword + r'\b'), '');
      }
      title = title.replaceAll(RegExp(r'[()\[\]|\-@/]'), '');

      List<String> parts = title
          .split(RegExp(r'\s+'))
          .where((part) => part.isNotEmpty)
          .toList()
        ..sort();

      return parts.join(" ").trim();
    }
    String normalizedTitle = normalizeTitle(songTitle);
    bool isDuplicate = relatedSongs.any((relatedSong){

      return normalizeTitle(relatedSong.song.title) == normalizedTitle;
    });

    return isDuplicate;
  }

  Future<void>_shuffleSongHistoryEvent(ShuffleSongHistoryEvent event,Emitter<Mp3StreamState> emit)async{

    shuffleBloc.add(ShuffleSongsEvent());

   await songHistory.fold(
        (relatedSongs)async{
          while(getRelatedSongsLength() != songsToFetch){
            await Future.delayed(const Duration(seconds: 1));
          }
          shuffledSongHistory = left([]);

          unShuffledSongHistory = left([]);
          listUsedForShuffle = left([]);
          unShuffledSongHistory= left(List.from(relatedSongs));

       shuffledSongHistory.leftMap((list){
            list.add(relatedSongs[currentSongIndex]);

          });

          listUsedForShuffle = left(List.from(relatedSongs));

          listUsedForShuffle.leftMap((list){
            list.removeAt(currentSongIndex);
          });
          listUsedForShuffle.leftMap((list){
            list.shuffle(Random());
          });
          shuffledSongHistory.leftMap((list){
            listUsedForShuffle.leftMap((listUsed){
              list.addAll(listUsed);
              songHistory = left(list);
            });
          });


          currentSongIndex = 0;
          emit(ShuffledSongHistoryState(event.song, songHistory, currentSongIndex));

        },
        (downloadedSongs){
          shuffledSongHistory = right([]);

          unShuffledSongHistory = right([]);
          listUsedForShuffle = right([]);
          unShuffledSongHistory= right(List.from(downloadedSongs));

          shuffledSongHistory.map((list){
            list.add(downloadedSongs[currentSongIndex]);

          });

          listUsedForShuffle = right(List.from(downloadedSongs));

          listUsedForShuffle.map((list){
            list.removeAt(currentSongIndex);
          });
          listUsedForShuffle.map((list){
            list.shuffle(Random());
          });
          shuffledSongHistory.map((list){
            listUsedForShuffle.map((listUsed){
              list.addAll(listUsed);
              songHistory = right(list);
            });
          });
          currentSongIndex = 0;
          emit(ShuffledSongHistoryState(event.song, songHistory, currentSongIndex));

        }
    );


  }

  Future<void>_unShuffleSongHistoryEvent(UnShuffleSongHistoryEvent event,Emitter<Mp3StreamState> emit)async{

    shuffleBloc.add(UnShuffleSongsEvent());


   await event.song.fold(
        (song)async{
          while(getRelatedSongsLength() != songsToFetch){
            await Future.delayed(const Duration(seconds: 1));
          }
          songHistory = unShuffledSongHistory;
           songHistory.leftMap((list){
             currentSongIndex = list.indexWhere((relatedSong)=> relatedSong.song.id == song.id);
           });
          unShuffledSongHistory = left([]);
          listUsedForShuffle = left([]);



          shuffledSongHistory = left([]);
          emit(UnShuffledSongHistoryState(event.song, songHistory, currentSongIndex));
        },
        (downloadedSong){
          songHistory = unShuffledSongHistory;
          songHistory.map((list){
            currentSongIndex = list.indexWhere((songDownloaded)=> songDownloaded.songFile == downloadedSong.songFile);
          });


          unShuffledSongHistory = right([]);
          shuffledSongHistory = right([]);
          listUsedForShuffle = right([]);
          emit(UnShuffledSongHistoryState(event.song, songHistory, currentSongIndex));
        }
    );

  }

  Future<void> _repeatCurrentSongEvent(RepeatCurrentSongEvent event,  Emitter<Mp3StreamState> emit)async{
    _cancelSubscriptions();
    await audioPlayer.stop();
    songPositionBloc.add(
        NewSongChangedEvent()
    );
    songHistory.fold(
        (relatedSongs){
          playSong(left(relatedSongs[currentSongIndex].song), relatedSongs[currentSongIndex].url, emit);
        },
        (downloadedSongs){
          playSong(right(downloadedSongs[currentSongIndex]), downloadedSongs[currentSongIndex].artist, emit);
        }
    );


  }

   Future<void> _repeatSongPlaylistEvent(RepeatSongPlaylistEvent event, Emitter<Mp3StreamState> emit)async{
     _cancelSubscriptions();
     await audioPlayer.stop();
     currentSongIndex = 0;
     songPositionBloc.add(
         NewSongChangedEvent()
     );
     songHistory.fold(
             (relatedSongs){
           playSong(left(relatedSongs[currentSongIndex].song), relatedSongs[currentSongIndex].url, emit);
         },
             (downloadedSongs){
           playSong(right(downloadedSongs[currentSongIndex]), downloadedSongs[currentSongIndex].artist, emit);
         }
     );
   }
   Future<void> _updateSongHistoryEvent(UpdateSongHistoryEvent event,Emitter<Mp3StreamState> emit)async{
    songHistory = event.songList;
    currentSongIndex = event.index;
     songHistory.fold((relatedSongs){
      emit(UpdateSongHistoryState(left(relatedSongs[currentSongIndex].song), left(relatedSongs), currentSongIndex));

    },

        (downloadedSongs){
       emit(UpdateSongHistoryState(right(downloadedSongs[currentSongIndex]), right(downloadedSongs), currentSongIndex));
        });
   }


  void _cancelSubscriptions() {
    _positionSubscription?.cancel();
    _processingStateSubscription?.cancel();
  }

  Future<void> _resetVariables(Either<Song,DownloadedSong> song)async{
    await audioPlayer.stop();

     relatedSongSubscription?.cancel();

    songsToFetch = 0;

    currentSongIndex = 0;
    song.fold((song){
      songHistory = left([]);
      unShuffledSongHistory = left([]);
      shuffledSongHistory = left([]);
      listUsedForShuffle = left([]);
    },
        (downloadedSong){
          songHistory = right([]);
          unShuffledSongHistory = right([]);
          shuffledSongHistory = right([]);
          listUsedForShuffle = right([]);
        }
    );
  }
  void updateFetchedRelatedSongs()async{

    songHistory.fold(
            (relatedSong)async{
          while(true) {
            await Future.delayed(const Duration(seconds: 1));
            add(UpdatePlayerState(left(relatedSong[currentSongIndex].song),
                RelatedSongFetchedState(const Duration(milliseconds: 500),
                    left(relatedSong[currentSongIndex].song), songHistory,
                    currentSongIndex)));
            if (getRelatedSongsLength() >= songsToFetch) {
              add(UpdatePlayerState(left(relatedSong[currentSongIndex].song),
                  RelatedSongFetchedState(const Duration(milliseconds: 500),
                      left(relatedSong[currentSongIndex].song), songHistory,
                      currentSongIndex)));
              break;
            }
          }
        },
            (downloadedSong){

        }
    );




  }
   int getRelatedSongsLength(){
    int length = 0;
    songHistory.leftMap(
        (relatedSongs){
          length = relatedSongs.length;
        },

    );
    return length;
   }
   int getDownloadedSongsLength(){
    print(songHistory);
    int length = 0;
    songHistory.map((downloadedSongs){
      length = downloadedSongs.length;
    });
    return length;
   }

  @override
  Future<void> close() {
    audioPlayer.dispose();
    _cancelSubscriptions();
    relatedSongSubscription?.cancel();
    return super.close();
  }
}
