part of 'song_position_bloc.dart';

sealed class SongPositionEvent extends Equatable {
  const SongPositionEvent();
}

final class UpdateSongPositionEvent extends SongPositionEvent{
  final Duration position;
  final Duration  totalDuration;

  const UpdateSongPositionEvent({required this.position,required this.totalDuration});
  @override
  // TODO: implement props
  List<Object?> get props => [position];

}

final class NewSongChangedEvent extends SongPositionEvent{

  @override
  // TODO: implement props
  List<Object?> get props => [];

}