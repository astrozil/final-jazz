import 'dart:core';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'song_position_event.dart';
part 'song_position_state.dart';

class SongPositionBloc extends Bloc<SongPositionEvent, SongPositionState> {
  SongPositionBloc() : super(const SongPositionInitial(position: Duration.zero,totalDuration: Duration.zero)) {
    on<UpdateSongPositionEvent>((event, emit)async {

      emit(SongPositionUpdatedState(position: event.position,
          totalDuration: event.totalDuration));

    });
    on<NewSongChangedEvent>((event,emit){

      emit(NewSongChangedState());
    });
  }
}
