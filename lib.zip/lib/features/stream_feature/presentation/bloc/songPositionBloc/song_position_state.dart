part of 'song_position_bloc.dart';

sealed class SongPositionState extends Equatable {
  const SongPositionState();
}

final class SongPositionInitial extends SongPositionState {
  final Duration position;
  final Duration  totalDuration;

  const SongPositionInitial({required this.position,required this.totalDuration});

  @override
  List<Object> get props => [];
}

final class SongPositionUpdatedState extends SongPositionState{
  final Duration position;
  final Duration  totalDuration;

  const SongPositionUpdatedState({required this.position,required this.totalDuration});

  @override

  List<Object?> get props => [position];

}

final class NewSongChangedState extends SongPositionState{

  @override
  // TODO: implement props
  List<Object?> get props => [];

}

