class Mp3Stream {
  final String url;

  Mp3Stream({required this.url});
}
